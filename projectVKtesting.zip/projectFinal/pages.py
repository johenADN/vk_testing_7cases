from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    PHONE_NUMBER_FIELD = (By.ID, "index_email")
    LOGIN_BUTTON = (By.XPATH, "//*[@class='FlatButton FlatButton--primary FlatButton--size-l FlatButton--wide VkIdForm__button VkIdForm__signInButton']")
    PASSWORD_FIELD = (By.NAME, "password")
    CONTINUE_BUTTON = (By.XPATH, '//*[@id="root"]/div/div/div/div/div[1]/div[1]/div/div/div/div/form/div[2]/button[1]/span')

    def __init__(self, driver):
        self.driver = driver

    def enter_phone_number(self, number):
        phone_number_field = self.driver.find_element(*self.PHONE_NUMBER_FIELD)
        phone_number_field.send_keys(number)

    def click_login_button(self):
        login_button = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.LOGIN_BUTTON))
        login_button.click()

    def enter_password(self, password):
        password_field = self.driver.find_element(*self.PASSWORD_FIELD)
        password_field.send_keys(password)

    def click_continue_button(self):
        continue_button = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.CONTINUE_BUTTON))
        continue_button.click()

class PostPage:
    def __init__(self, driver):
        self.driver = driver

    def create_post(self, content):
        post_field = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.ID, "post_field")))
        post_field.send_keys(content)
        post_field.send_keys(Keys.ENTER)
