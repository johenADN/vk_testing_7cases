import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver import Keys

driver = webdriver.Chrome()
driver.get("https://vk.com/")
driver.maximize_window()
time.sleep(5)

# first test case login
phoneNumber = driver.find_element(By.ID, "index_email")
phoneNumber.send_keys("87789054404")
time.sleep(5)

button = driver.find_element(By.XPATH, "//*[@class='FlatButton FlatButton--primary FlatButton--size-l FlatButton--wide VkIdForm__button VkIdForm__signInButton']")
button.click()
time.sleep(5)

password = driver.find_element(By.NAME, "password")
password.send_keys("Aidyn466923")
time.sleep(6)

continue1 = driver.find_element(By.XPATH, '//*[@id="root"]/div/div/div/div/div[1]/div[1]/div/div/div/div/form/div[2]/button[1]/span')
continue1.click()
time.sleep(7)

# 2 test case post a post
post = driver.find_element(By.ID, "post_field")
post.send_keys("this is my project testing")
time.sleep(5)

driver.find_element(By.ID, 'send_post').click()
time.sleep(7)
# check the post
driver.find_element(By.ID, 'l_pr').click()
time.sleep(7)
driver.execute_script("window.scrollTo(0, 700);")
time.sleep(7)

# 3 test case search Batyr Aliturliyev and Aidyn Aliturliyev
search = driver.find_element(By.ID, "search-:r0:")
search.send_keys("Batyr Aliturliyev")
search.send_keys(Keys.ENTER)
time.sleep(6)

search = driver.find_element(By.ID, "search-:r0:")
search.send_keys("Aidyn Aliturliyev")
search.send_keys(Keys.ENTER)
time.sleep(6)

# ????4 test case send message Aidyn Aliturliyev
driver.find_element(By.ID, 'l_msg').click()
time.sleep(7)
driver.find_element(By.XPATH, '//*[@id="im_dialogs"]/li/div[2]').click()
time.sleep(5)
send_message = driver.find_element(By.ID, "im_editable0")
send_message.send_keys("Kalaisyn?")
send_message.send_keys(Keys.ENTER)
time.sleep(6)

#5 filter friends, male or female
driver.find_element(By.ID, 'l_fr').click() #friends page
time.sleep(7)

driver.find_element(By.XPATH, '//*[@id="friends_search_input_wrap"]/div/div[1]/div[1]/a').click() #parameters
time.sleep(7)
driver.find_element(By.XPATH, '//*[@id="friends_sex_radio"]/div[2]').click() #click male filter
time.sleep(7)
driver.find_element(By.XPATH, '//*[@id="friends_search_input_wrap"]/div/div[1]/button').click() # click search icon you see male friends
time.sleep(7)

#6 test case change to white mode
driver.find_element(By.XPATH, '//*[@id="top_profile_link"]').click() #top profile
time.sleep(7)
driver.find_element(By.XPATH, '//*[@id="top_profile_menu"]/a[2]/span/div/div/div').click()
time.sleep(7)
driver.find_element(By.ID, 'idd_item_light').click()
time.sleep(7)
driver.find_element(By.XPATH, '//*[@id="top_nav"]/li[1]/a[1]').click() #main page
time.sleep(7)

#7 test case logout
driver.find_element(By.XPATH, '//*[@id="top_profile_link"]').click() #top profile
time.sleep(7)
driver.find_element(By.ID, 'top_logout_link').click() #logout
time.sleep(7)

