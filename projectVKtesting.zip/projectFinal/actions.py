import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages import LoginPage, PostPage

@pytest.fixture(scope="module")
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    yield driver
    driver.quit()

@pytest.mark.parametrize('phone_number, password', [("YOUR_NUMBER", "YOUR_PASSWORD")])
def test_login(driver, phone_number, password):
    driver.get("https://vk.com/")
    login_page = LoginPage(driver)
    login_page.enter_phone_number(phone_number)
    login_page.click_login_button()
    time.sleep(5)
    login_page.enter_password(password)
    login_page.click_continue_button()
    time.sleep(8)

def test_post(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")
    post_page = PostPage(driver)
    post_page.create_post("this is my project testing")

    send_post_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, 'send_post'))
    )
    send_post_button.click()
    time.sleep(7)

    profile_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, 'l_pr'))
    )
    profile_link.click()
    time.sleep(7)

    driver.execute_script("window.scrollTo(0, 700);")
    time.sleep(7)

    post_content = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.XPATH, "//div[contains(text(), 'this is my project testing')]"))
    )
    assert "this is my project testing" in post_content.text

def test_search(driver):
    # Вход в систему
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")

    # Найти поле поиска и ввести запрос
    search_query = "Batyr Aliturliyev"  # Change this to the name you want to search for
    search = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "search-:r0:"))
    )
    search.send_keys(search_query)
    search.send_keys(Keys.ENTER)

    # Проверка наличия текста на странице
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, f"//*[contains(text(), '{search_query}')]"))
    )
    page_source = driver.page_source
    assert search_query in page_source

def test_send_message(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")
    driver.find_element(By.ID, 'l_msg').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="im_dialogs"]/li/div[2]').click()
    time.sleep(5)
    send_message = driver.find_element(By.ID, "im_editable0")
    send_message.send_keys("Kalaisyn?")
    send_message.send_keys(Keys.ENTER)
    message = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//*[contains(text(), 'Kalaisyn?')]")))
    assert "Kalaisyn?" in message.text


def test_filter_friends(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")
    driver.find_element(By.ID, 'l_fr').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="friends_search_input_wrap"]/div/div[1]/div[1]/a').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="friends_sex_radio"]/div[2]').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="friends_search_input_wrap"]/div/div[1]/button').click()
    male_friends = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//*[contains(@class, 'friends_field sex')]")))
    assert male_friends is not None

def test_change_mode(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")
    driver.find_element(By.XPATH, '//*[@id="top_profile_link"]').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="top_profile_menu"]/a[2]/span/div/div/div').click()
    time.sleep(7)
    driver.find_element(By.ID, 'idd_item_light').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="top_nav"]/li[1]/a[1]').click()
    light_mode = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//*[contains(@class, 'top_nav')]")))
    assert light_mode is not None

def test_logout(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_PASSWORD")
    driver.find_element(By.XPATH, '//*[@id="top_profile_link"]').click()
    time.sleep(7)
    driver.find_element(By.ID, 'top_logout_link').click()
    time.sleep(7)

def test_wrong_password(driver):
    test_login(driver, "YOUR_NUMBER", "YOUR_WRONG_PASSWORD")
    error_message = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//div[contains(text(), 'Incorrect password.')]")))
    assert "Incorrect password." in error_message.text